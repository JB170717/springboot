package com.simple.basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
